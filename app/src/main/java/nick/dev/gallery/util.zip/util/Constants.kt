package nick.dev.gallery.util

object Constants {
    const val API_KEY  = "563492ad6f9170000100000193d8705a4a264c9681d553eeb0ece358"
}